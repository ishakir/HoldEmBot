package action

import state.MatchState

object Action {
  def chooseActions(state: MatchState): Seq[String] = {
    Analyser(state).actions
  }
}

object Analyser {
  def apply(state: MatchState): Analyser = state.currentRound.isPreFlop match {
    case true => new PreFlopAnalyser(state)
    // TODO change me back!
    case false => new PreFlopAnalyser(state)
  }
}
abstract class Analyser {
  val actions: Seq[String]
}

class PostFlopAnalyser(state: MatchState) extends Analyser {
  override lazy val actions: Seq[String] = Seq("check 0")
}

class PreFlopAnalyser(state: MatchState) extends Analyser {
  override lazy val actions: Seq[String] = {
    val round = state.currentRound
    val myBotName = state.settings.yourBot
    val amountToCall = round.amountToCallFor(myBotName)
    val myRemainingStack = round.stackLeftFor(myBotName)
    if(round.handIsPair) {
      val stackOverFive = myRemainingStack / 5

      // Attempt to bet 1/5 of remaining stack
      if(amountToCall > stackOverFive) Seq("fold 0")
      else if(amountToCall == 0) Seq(s"raise $stackOverFive")
      else {
        val difference = stackOverFive - amountToCall
        Seq(s"raise $difference")
      }
    } else {
      // Do we need / want to call anything?
      if(amountToCall > round.stackLeftFor(myBotName) / 10) Seq("fold 0")
      else if(amountToCall > 0) Seq(s"call $amountToCall")
      else Seq("check 0")
    }
  }
}