package playingcard

import playingcard.Rank.Rank

// Most stuff in this class should be Set rather than Seq, but this caused some issues
// Need to sort that out at some point
class Hand(val cards: Seq[PlayingCard]) {
  assert(cards.size == 5, "A poker hand must have 5 cards, $cards does not")

  lazy val isRoyalFlush = isStraightFlush &&
    cards.exists(card => card.rank == Rank.Ace) &&
    cards.exists(card => card.rank == Rank.King)

  lazy val isStraightFlush = isFlush && isStraight

  lazy val isFlush: Boolean = cards.filter(card => card.suit != cards.head.suit).size == 0

  lazy val isStraight: Boolean = chooseOne(cards.map(card => card.rank.values)).exists( values => {
    val sortedValues = values.sorted
    sortedValues.foldLeft((sortedValues.head, true)) {
      case ((expected, isStraightSoFar), actual) => (expected + 1, isStraightSoFar && expected == actual)
    }}._2
  )

  lazy val hasPair: Boolean = hasNofAKind(2)
  lazy val hasTriple: Boolean = hasNofAKind(3)
  lazy val isFourOfAKind: Boolean = hasNofAKind(4)

  lazy val isFullHouse: Boolean = hasPair && hasTriple

  private def hasNofAKind(n: Int): Boolean = groupedByRank.values.exists(seq => seq.size == n)
  private lazy val groupedByRank: Map[Rank, Seq[PlayingCard]] = cards.groupBy(card => card.rank)

  // This could be much nicer and is probably in the wrong place
  // But will do for now, required in order to allow ace low
  // and ace high straights
  def chooseOne[T](sequences: Seq[Seq[T]]): Seq[Seq[T]] = {
    assert(sequences.size == 5)
    for(
      x1 <- sequences.head;
      x2 <- sequences.tail.head;
      x3 <- sequences.tail.tail.head;
      x4 <- sequences.tail.tail.tail.head;
      x5 <- sequences.tail.tail.tail.tail.head
    ) yield Seq(x1, x2, x3, x4, x5)
  }
}