package playingcard

import scala.util.Random

object Suit {
  sealed abstract class Suit(val char: Char)

  case object Clubs extends Suit('c')
  case object Diamonds extends Suit('d')
  case object Hearts extends Suit('h')
  case object Spades extends Suit('s')

  val values: Seq[Suit] = Seq(Clubs, Diamonds, Hearts, Spades)

  def parse(char: Char) = values.find(s => s.char == char).getOrElse(throw new IllegalArgumentException(s"No Suit parseable from char $char"))
}

object Rank {
  sealed abstract class Rank(val char: Char, val values: Seq[Int]) extends Ordered[Rank] {
    // The only way to order at the moment is ace-high, this can be changed
    override def compare(that: Rank) = {
      if(values.max > that.values.max) 1
      else if(values.max < that.values.max) -1
      else 0
    }
  }

  case object Ace extends Rank('A', Seq(1, 14))
  case object Two extends Rank('2', Seq(2))
  case object Three extends Rank('3', Seq(3))
  case object Four extends Rank('4', Seq(4))
  case object Five extends Rank('5', Seq(5))
  case object Six extends Rank('6', Seq(6))
  case object Seven extends Rank('7', Seq(7))
  case object Eight extends Rank('8', Seq(8))
  case object Nine extends Rank('9', Seq(9))
  case object Ten extends Rank('T', Seq(10))
  case object Jack extends Rank('J', Seq(11))
  case object Queen extends Rank('Q', Seq(12))
  case object King extends Rank('K', Seq(13))

  val values: Seq[Rank] = Seq(Ace, Two, Three, Four, Five, Six, Seven, Eight, Nine, Ten, Jack, Queen, King)

  def parse(char: Char) = values.find(r => r.char == char).getOrElse(throw new IllegalArgumentException(s"No Rank parseable from char $char"))

}

object PlayingCard {
  def parse(str: String): PlayingCard = {
    assert(str.length == 2, "Parseable cards are of the form \"RS\" where R is rank, S is suit. Not '"+str+"'")
    val rankChar = str.charAt(0)
    val suitChar = str.charAt(1)
    new PlayingCard(Rank.parse(rankChar), Suit.parse(suitChar))
  }
}

class PlayingCard(val rank: Rank.Rank, val suit: Suit.Suit) extends Ordered[PlayingCard] {
  override def compare(that: PlayingCard): Int = rank.compare(that.rank)
  override lazy val toString: String = rank.char.toString + suit.char.toString
}

object Deck {
  lazy val orderedDeck = for(suit <- Suit.values; rank <- Rank.values) yield new PlayingCard(rank, suit)
  def newShuffledDeck() = Random.shuffle(orderedDeck)
}