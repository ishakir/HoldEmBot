import state.MatchState

import scala.annotation.tailrec

/**
 * Created by imran on 05/04/15.
 */
object Main extends App {
  override def main (args: Array[String]) {
    recurse(io.Source.stdin.getLines(), MatchState.initial)
  }

  @tailrec
  def recurse(inputs: Iterator[String], state: MatchState): Unit = {
    if(!inputs.hasNext) return
    else {
      val line: String = inputs.next()
      val (newState: MatchState, responses: Seq[String]) = processInput(state, line)

      // Log out the current state
      System.err.println(newState)

      // Print out actions to stdout
      for(response <- responses) println(response)

      // Aaaand continue
      recurse(inputs, newState)
    }
  }

  def processInput(state: MatchState, line: String): (MatchState, Seq[String]) = {
    val args = line.split(" ").toSeq
    args.head match {
      case "Settings" => (state.updateSetting(args.tail.head, args.tail.tail.head), Seq())
      case "Match"    => (state.updateRound(args.tail.head, args.tail.tail.head), Seq())
      case "Action"   => (state, Seq("check 0"))
    }
  }

}
