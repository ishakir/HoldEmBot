package action

import playingcard.{HighCard, PokerAnalysis, HandScore}
import state.MatchState

object Action {
  def chooseActions(state: MatchState): Seq[String] = {
    Analyser(state).actions
  }
}

object Analyser {
  def apply(state: MatchState): Analyser = state.currentRound.isPreFlop match {
    case true => new PreFlopAnalyser(state)
    case false => new PostFlopAnalyser(state)
  }
}

abstract class Analyser(val state: MatchState) {
  lazy val actions: Seq[String] = {
    System.err.println(probabilities)

    val betAggressively = probabilities.get(HighCard) match {
      case Some(x)  => if(x < 0.3) true else false
      case None     => true
    }

    val round = state.currentRound
    val myBotName = state.settings.yourBot
    val amountToCall = round.amountToCallFor(myBotName)

    if(betAggressively) {
      System.err.println("Chose to bet aggresively")
      val myRemainingStack = round.stackLeftFor(myBotName)
      val stackOverFive = myRemainingStack / 5

      // Attempt to bet 1/5 of remaining stack
      if(amountToCall > stackOverFive) Seq("fold 0")
      else if(amountToCall == 0) Seq(s"raise $stackOverFive")
      else {
        val difference = stackOverFive - amountToCall
        Seq(s"raise $difference")
      }
    } else {
      System.err.println("Chose to bet non-aggressively")

      // Do we need / want to call anything?
      if(amountToCall > round.stackLeftFor(myBotName) / 25) Seq("fold 0")
      else if(amountToCall > 0) Seq(s"call $amountToCall")
      else Seq("check 0")
    }


  }

  val probabilities: Map[HandScore, Double]
}

class PostFlopAnalyser(state: MatchState) extends Analyser(state) {
  override val probabilities: Map[HandScore, Double] = new PokerAnalysis(state.currentRound.handAsSet, state.currentRound.table.allCards, 5).scoreToProbability
}

class PreFlopAnalyser(state: MatchState) extends Analyser(state) {
  override val probabilities: Map[HandScore, Double] = if(state.currentRound.handIsPair) Map(HighCard -> 0) else Map(HighCard -> 1)
}