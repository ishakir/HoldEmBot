package state

// This is in another library
abstract class PlayingCard
object Fake extends PlayingCard

/**
 * Created by imran on 05/04/15.
 */
class MatchState(val settings: Settings, currentRound: Round, pastRounds: Seq[Round]) {
  def updateSetting(key: String, value: String): MatchState = new MatchState(settings.update(key, value), currentRound, pastRounds)
  def updateRound(key: String, value: String): MatchState = key match {
    case "wins" => new MatchState(settings, Round.initial, currentRound +: pastRounds)
    case _      => new MatchState(settings, currentRound.updateRound(key, value), pastRounds)
  }

  override lazy val toString: String =
    s"""MatchState:
       |  Settings: $settings
     """.stripMargin
}

object MatchState {
  val initial = new MatchState(
    Settings.initial,
    Round.initial,
    Seq()
  )
}

class Round(number: Int, smallBlind: Int, bigBlind: Int, onButton: String, money: Map[String, StackBet], hand: (PlayingCard, PlayingCard), table: Table) {
  def updateRound(key: String, value: String): Round = this
}
object Round {
  def initial = new Round(0, 0, 0, "", Map(), (Fake, Fake), Table.initial)
}

class StackBet(stack: Int, bet: Int)

object Table { val initial = new Table(None, None, None) }
class Table(flop: Option[(PlayingCard, PlayingCard, PlayingCard)], turn: Option[PlayingCard], river: Option[PlayingCard])

object Settings { val initial = new Settings(0, 0, 0, 0, "") }
class Settings(val timeBank: Int, timePerMove: Int, handsPerLevel: Int, startingStack: Int, yourBot: String) {
  def update(key: String, value: String): Settings = key match {
    case "time_bank"       => new Settings(value.toInt, timePerMove, handsPerLevel, startingStack, yourBot)
    case "time_per_move"   => new Settings(timeBank, value.toInt, handsPerLevel, startingStack, yourBot)
    case "hands_per_level" => new Settings(timeBank, timePerMove, value.toInt, startingStack, yourBot)
    case "starting_stack"  => new Settings(timeBank, timePerMove, handsPerLevel, value.toInt, yourBot)
    case "your_bot"        => new Settings(timeBank, timePerMove, handsPerLevel, startingStack, value)
  }

  private lazy val toMap: Map[String, String] = Map(
    "time_bank"       -> timeBank.toString,
    "time_per_move"   -> timePerMove.toString,
    "hands_per_level" -> handsPerLevel.toString,
    "starting_stack"  -> startingStack.toString,
    "your_bot"        -> yourBot
  )

  override val toString: String = toMap.toString()
}
