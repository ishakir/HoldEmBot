package state

import playingcard.PlayingCard

object Table {
  val initial = new Table(None, None, None)
}

class Table(flop: Option[(PlayingCard, PlayingCard, PlayingCard)], turn: Option[PlayingCard], river: Option[PlayingCard]) {
  def update(str: Array[String]): Table = {
    val cards = str.map(st => PlayingCard.parse(st))
    cards.length match {
      case 0 => Table.initial
      case n if n >= 3 && n <= 5 => {
        val flop = Some((cards(0), cards(1), cards(2)))
        cards.length match {
          case 3 => new Table(flop, None, None)
          case 4 => new Table(flop, Some(cards(3)), None)
          case 5 => new Table(flop, Some(cards(3)), Some(cards(4)))
        }
      }
    }
  }

  private lazy val toMap: Map[String, Any] = Map(
    "flop"  -> flop,
    "turn"  -> turn,
    "river" -> river
  )

  override lazy val toString: String = toMap.toString()
}